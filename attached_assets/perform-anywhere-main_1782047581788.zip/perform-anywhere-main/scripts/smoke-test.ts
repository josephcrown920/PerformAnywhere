/**
 * Backend smoke tests — exercises every provider adapter via the portable
 * orchestration runner and prints a ready/failing matrix.
 *
 * Run locally:    bun run scripts/smoke-test.ts
 * Run in CI:      same — exits 0 if at least one provider per modality is OK.
 */
import { runOrchestrated } from "../src/lib/orchestrate/run.server";
import { ADAPTERS } from "../src/lib/orchestrate/providers.server";
import { CATALOG, type Modality } from "../src/lib/orchestrate/catalog";

type Row = { modality: Modality; provider: string; status: "ok" | "unconfigured" | "fail"; note: string; ms: number };

async function probe(modality: Modality, provider: string): Promise<Row> {
  const model = CATALOG[modality].find((m) => m.provider === provider)?.model ?? "";
  if (!model) return { modality, provider, status: "fail", note: "no_catalog_entry", ms: 0 };
  const started = Date.now();
  try {
    await runOrchestrated({
      modality,
      modelId: `${provider}/${model}`,
      prompt: modality === "text" ? "ping" : "a red circle",
      fallback: [provider], // isolate this provider only
    });
    return { modality, provider, status: "ok", note: "", ms: Date.now() - started };
  } catch (e: any) {
    const msg = String(e?.message ?? e);
    const status = msg.includes("unconfigured") ? "unconfigured" : "fail";
    return { modality, provider, status, note: msg.slice(0, 80), ms: Date.now() - started };
  }
}

async function main() {
  const rows: Row[] = [];
  const modalities: Modality[] = ["text", "image", "video", "audio"];

  for (const modality of modalities) {
    const providers = Object.keys(ADAPTERS[modality]);
    const results = await Promise.all(providers.map((p) => probe(modality, p)));
    rows.push(...results);
  }

  const pad = (s: string, n: number) => s + " ".repeat(Math.max(0, n - s.length));
  console.log("\n=== Backend Smoke Test Results ===\n");
  console.log(pad("modality", 8), pad("provider", 14), pad("status", 14), "time   note");
  console.log("-".repeat(80));
  for (const r of rows) {
    const icon = r.status === "ok" ? "✅" : r.status === "unconfigured" ? "⚪" : "❌";
    console.log(pad(r.modality, 8), pad(r.provider, 14), pad(`${icon} ${r.status}`, 14), `${pad(r.ms + "ms", 6)} ${r.note}`);
  }

  // Summary: pass if every modality has at least one OK provider.
  const byModality = new Map<Modality, Row[]>();
  for (const r of rows) byModality.set(r.modality, [...(byModality.get(r.modality) ?? []), r]);

  console.log("\n=== Per-modality readiness ===");
  let failed = 0;
  for (const [m, rs] of byModality) {
    const ok = rs.filter((r) => r.status === "ok").length;
    const total = rs.length;
    const ready = ok > 0;
    console.log(`  ${ready ? "✅" : "❌"} ${m}: ${ok}/${total} providers ready`);
    if (!ready) failed++;
  }

  if (failed > 0) {
    console.error(`\n❌ ${failed} modality/modalities have no working provider.`);
    process.exit(1);
  }
  console.log("\n✅ All modalities have at least one working provider.\n");
}

main().catch((e) => {
  console.error("smoke test crashed:", e);
  process.exit(2);
});
