# Make the backend anonymous

The frontend auth gate is already gone. Now make the data layer work without `auth.users`. Identity becomes a **client id** (UUID stored in `localStorage`) that the browser passes to every server function. No accounts, no signups — but each browser still sees its own projects/credits.

## Identity model

- Client generates and persists a UUID in `localStorage` under `ps_client_id`.
- A small helper `getClientId()` returns it; missing → generate + store.
- Every server function takes `clientId: string` (UUID) as validated input.
- All tables that had `user_id uuid` get a new `client_id uuid` column (kept alongside the old column for one migration so existing rows don't break, then `user_id` made nullable).

## Database migration

For each of `projects`, `project_assets`, `project_renders`, `generations`, `credit_wallets`, `credit_ledger`, `purchases`:

1. Add `client_id uuid` (indexed).
2. Backfill `client_id := user_id` for existing rows.
3. Make `user_id` nullable.
4. Drop the existing `auth.uid() = user_id` policies.
5. Replace with permissive `USING (true) WITH CHECK (true)` policies, since we cannot identify the caller server-side without a JWT. Security boundary moves to the server function: it filters by the validated `client_id`.
6. Re-grant `SELECT, INSERT, UPDATE, DELETE` to `anon` (and keep `authenticated`/`service_role`).

Drop `profiles`, `user_roles`, `has_role`, `handle_new_user` — not used in the anonymous flow. Keep `spend_credits`/`grant_credits` but change their signature from `_user_id` to `_client_id` (or just rename the column inside and accept either).

Tradeoff to acknowledge: `anon` can technically read any row by guessing UUIDs, since RLS becomes permissive. Acceptable for a public demo; not acceptable for real PII.

## Server functions

Replace `requireSupabaseAuth` middleware with the publishable-key server client (anon). Each handler:

```ts
.inputValidator((d: { clientId: string, ... }) => d)
.handler(async ({ data }) => {
  const supabase = createPublicClient();
  // filter every query/insert by data.clientId
})
```

Files touched:
- `src/lib/orchestrate.functions.ts` — startGeneration, getCreditBalance, listProjects, createProject
- `src/lib/render.functions.ts` — all 6 fns (use `clientId` instead of `userId`; storage paths become `${clientId}/...`)
- `src/lib/prompt.functions.ts` — drop middleware, becomes pure
- Delete `requireSupabaseAuth` usages; leave the file in place (still wired in `src/start.ts`, but unused).

Storage buckets `uploads` and `renders` get permissive policies: any authenticated OR anon role can read/write objects under any path. (Or keep the path prefix convention but stop enforcing it via RLS.)

## Frontend

- New `src/lib/client-id.ts` exporting `getClientId()` (browser-only, lazy localStorage).
- Update `src/routes/_authenticated/projects/index.tsx`, `$id.tsx`, `studio.tsx`, `orchestrate.tsx`, `account.tsx` to pull `clientId` from `getClientId()` and pass it into every server-fn call.
- `useQuery` keys gain `clientId` so caches separate per browser.
- `account.tsx`: replace "signed in as / sign out" with "Anonymous session — Reset" button (clears localStorage + reloads).

## Out of scope

- Multi-device sync (no accounts = no sync).
- Migrating existing real users — there aren't any yet beyond test accounts; existing rows survive because `client_id` is backfilled from `user_id`.
- Payments via `purchases` (Stripe needs a customer; can be wired to `client_id` later).

## Verification

1. Reset browser localStorage → `/projects` shows empty list with no errors.
2. Create a project → appears in list; refresh keeps it.
3. Open in incognito → empty list (different client id).
4. Start a generation → credits debited from the wallet keyed by `client_id`.
5. `bun run scripts/smoke-test.ts` still passes.

Confirm and I'll execute.
