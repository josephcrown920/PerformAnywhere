ALTER TABLE public.credit_ledger   DROP CONSTRAINT IF EXISTS credit_ledger_user_id_fkey;
ALTER TABLE public.credit_wallets   DROP CONSTRAINT IF EXISTS credit_wallets_user_id_fkey;
ALTER TABLE public.generations      DROP CONSTRAINT IF EXISTS generations_user_id_fkey;
ALTER TABLE public.project_assets   DROP CONSTRAINT IF EXISTS project_assets_user_id_fkey;
ALTER TABLE public.project_renders  DROP CONSTRAINT IF EXISTS project_renders_user_id_fkey;
ALTER TABLE public.projects         DROP CONSTRAINT IF EXISTS projects_user_id_fkey;
ALTER TABLE public.purchases        DROP CONSTRAINT IF EXISTS purchases_user_id_fkey;