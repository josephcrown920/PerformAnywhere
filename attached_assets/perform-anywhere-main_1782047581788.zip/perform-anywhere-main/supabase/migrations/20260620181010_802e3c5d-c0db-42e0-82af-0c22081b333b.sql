-- Modality + status enums
DO $$ BEGIN
  CREATE TYPE public.gen_modality AS ENUM ('text','image','video','audio','inference','sync');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.gen_status AS ENUM ('queued','running','succeeded','failed');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE public.ledger_reason AS ENUM ('purchase','generation','refund','grant','adjustment');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 1) credit_wallets
CREATE TABLE IF NOT EXISTS public.credit_wallets (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  balance integer NOT NULL DEFAULT 0 CHECK (balance >= 0),
  lifetime_purchased integer NOT NULL DEFAULT 0,
  lifetime_spent integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.credit_wallets TO authenticated;
GRANT ALL ON public.credit_wallets TO service_role;
ALTER TABLE public.credit_wallets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own wallet" ON public.credit_wallets
  FOR SELECT TO authenticated USING (user_id = auth.uid());

-- 2) credit_ledger
CREATE TABLE IF NOT EXISTS public.credit_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  delta integer NOT NULL,
  reason public.ledger_reason NOT NULL,
  description text,
  generation_id uuid,
  purchase_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.credit_ledger TO authenticated;
GRANT ALL ON public.credit_ledger TO service_role;
ALTER TABLE public.credit_ledger ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own ledger" ON public.credit_ledger
  FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE INDEX IF NOT EXISTS credit_ledger_user_created_idx ON public.credit_ledger(user_id, created_at DESC);

-- 3) generations
CREATE TABLE IF NOT EXISTS public.generations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  modality public.gen_modality NOT NULL,
  provider text NOT NULL,
  model text NOT NULL,
  prompt text,
  options jsonb NOT NULL DEFAULT '{}'::jsonb,
  status public.gen_status NOT NULL DEFAULT 'queued',
  output_url text,
  output_text text,
  output jsonb,
  credits_used integer NOT NULL DEFAULT 0,
  duration_ms integer,
  error_message text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.generations TO authenticated;
GRANT ALL ON public.generations TO service_role;
ALTER TABLE public.generations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own generations" ON public.generations
  FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE INDEX IF NOT EXISTS generations_user_created_idx ON public.generations(user_id, created_at DESC);

-- 4) purchases
CREATE TABLE IF NOT EXISTS public.purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  paystack_reference text UNIQUE NOT NULL,
  amount_paid_minor bigint NOT NULL,
  currency text NOT NULL DEFAULT 'NGN',
  credits_allocated integer NOT NULL,
  raw_event jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.purchases TO authenticated;
GRANT ALL ON public.purchases TO service_role;
ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own purchases" ON public.purchases
  FOR SELECT TO authenticated USING (user_id = auth.uid());

-- updated_at triggers
DROP TRIGGER IF EXISTS trg_wallets_updated_at ON public.credit_wallets;
CREATE TRIGGER trg_wallets_updated_at BEFORE UPDATE ON public.credit_wallets
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
DROP TRIGGER IF EXISTS trg_generations_updated_at ON public.generations;
CREATE TRIGGER trg_generations_updated_at BEFORE UPDATE ON public.generations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Auto-create wallet when a profile is created (extend handle_new_user)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', split_part(NEW.email,'@',1)),
    NEW.raw_user_meta_data->>'avatar_url'
  ) ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.credit_wallets (user_id, balance)
  VALUES (NEW.id, 50)  -- 50 free starter credits
  ON CONFLICT (user_id) DO NOTHING;

  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Atomic credit-spend RPC (server-only writes)
CREATE OR REPLACE FUNCTION public.spend_credits(
  _user_id uuid, _amount integer, _reason public.ledger_reason,
  _description text, _generation_id uuid
) RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE new_balance integer;
BEGIN
  IF _amount <= 0 THEN RAISE EXCEPTION 'amount must be positive'; END IF;

  INSERT INTO public.credit_wallets (user_id, balance) VALUES (_user_id, 0)
  ON CONFLICT (user_id) DO NOTHING;

  UPDATE public.credit_wallets
    SET balance = balance - _amount,
        lifetime_spent = lifetime_spent + _amount
    WHERE user_id = _user_id AND balance >= _amount
    RETURNING balance INTO new_balance;

  IF new_balance IS NULL THEN RAISE EXCEPTION 'insufficient_credits'; END IF;

  INSERT INTO public.credit_ledger (user_id, delta, reason, description, generation_id)
  VALUES (_user_id, -_amount, _reason, _description, _generation_id);

  RETURN new_balance;
END; $$;

CREATE OR REPLACE FUNCTION public.grant_credits(
  _user_id uuid, _amount integer, _reason public.ledger_reason,
  _description text, _purchase_id uuid
) RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public' AS $$
DECLARE new_balance integer;
BEGIN
  IF _amount <= 0 THEN RAISE EXCEPTION 'amount must be positive'; END IF;
  INSERT INTO public.credit_wallets (user_id, balance, lifetime_purchased)
  VALUES (_user_id, _amount, CASE WHEN _reason='purchase' THEN _amount ELSE 0 END)
  ON CONFLICT (user_id) DO UPDATE
    SET balance = public.credit_wallets.balance + EXCLUDED.balance,
        lifetime_purchased = public.credit_wallets.lifetime_purchased +
          CASE WHEN _reason='purchase' THEN _amount ELSE 0 END
  RETURNING balance INTO new_balance;

  INSERT INTO public.credit_ledger (user_id, delta, reason, description, purchase_id)
  VALUES (_user_id, _amount, _reason, _description, _purchase_id);

  RETURN new_balance;
END; $$;

REVOKE ALL ON FUNCTION public.spend_credits(uuid,integer,public.ledger_reason,text,uuid) FROM public;
REVOKE ALL ON FUNCTION public.grant_credits(uuid,integer,public.ledger_reason,text,uuid) FROM public;
GRANT EXECUTE ON FUNCTION public.spend_credits(uuid,integer,public.ledger_reason,text,uuid) TO service_role;
GRANT EXECUTE ON FUNCTION public.grant_credits(uuid,integer,public.ledger_reason,text,uuid) TO service_role;