
-- 1. Drop existing policies that reference user_id
DROP POLICY IF EXISTS "Users view own ledger" ON public.credit_ledger;
DROP POLICY IF EXISTS "Users view own wallet" ON public.credit_wallets;
DROP POLICY IF EXISTS "Users manage own generations" ON public.generations;
DROP POLICY IF EXISTS "Users manage own assets" ON public.project_assets;
DROP POLICY IF EXISTS "Users manage own renders" ON public.project_renders;
DROP POLICY IF EXISTS "Users manage own projects" ON public.projects;
DROP POLICY IF EXISTS "Users view own purchases" ON public.purchases;

-- 2. Drop account-only tables and helpers
DROP TABLE IF EXISTS public.user_roles CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;
DROP TYPE IF EXISTS public.app_role CASCADE;
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role) CASCADE;
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;

-- 3. Rename user_id -> client_id everywhere
ALTER TABLE public.projects        RENAME COLUMN user_id TO client_id;
ALTER TABLE public.project_assets  RENAME COLUMN user_id TO client_id;
ALTER TABLE public.project_renders RENAME COLUMN user_id TO client_id;
ALTER TABLE public.generations     RENAME COLUMN user_id TO client_id;
ALTER TABLE public.credit_wallets  RENAME COLUMN user_id TO client_id;
ALTER TABLE public.credit_ledger   RENAME COLUMN user_id TO client_id;
ALTER TABLE public.purchases       RENAME COLUMN user_id TO client_id;

-- 4. Indexes on client_id
CREATE INDEX IF NOT EXISTS projects_client_id_idx        ON public.projects(client_id);
CREATE INDEX IF NOT EXISTS project_assets_client_id_idx  ON public.project_assets(client_id);
CREATE INDEX IF NOT EXISTS project_renders_client_id_idx ON public.project_renders(client_id);
CREATE INDEX IF NOT EXISTS generations_client_id_idx     ON public.generations(client_id);
CREATE INDEX IF NOT EXISTS credit_ledger_client_id_idx   ON public.credit_ledger(client_id);
CREATE INDEX IF NOT EXISTS purchases_client_id_idx       ON public.purchases(client_id);

-- 5. Permissive RLS policies (server fns enforce client_id scoping)
CREATE POLICY "anon full access" ON public.projects        FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "anon full access" ON public.project_assets  FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "anon full access" ON public.project_renders FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "anon full access" ON public.generations     FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "anon full access" ON public.credit_wallets  FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "anon full access" ON public.credit_ledger   FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "anon full access" ON public.purchases       FOR ALL USING (true) WITH CHECK (true);

-- 6. Grants for anon (in addition to existing authenticated/service_role)
GRANT SELECT, INSERT, UPDATE, DELETE ON public.projects        TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.project_assets  TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.project_renders TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.generations     TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.credit_wallets  TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.credit_ledger   TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.purchases       TO anon, authenticated;
GRANT ALL ON public.projects, public.project_assets, public.project_renders,
              public.generations, public.credit_wallets, public.credit_ledger,
              public.purchases TO service_role;

-- 7. Replace spend_credits / grant_credits with client_id signature
DROP FUNCTION IF EXISTS public.spend_credits(uuid, integer, ledger_reason, text, uuid);
DROP FUNCTION IF EXISTS public.grant_credits(uuid, integer, ledger_reason, text, uuid);

CREATE OR REPLACE FUNCTION public.spend_credits(
  _client_id uuid, _amount integer, _reason ledger_reason,
  _description text, _generation_id uuid
) RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE new_balance integer;
BEGIN
  IF _amount <= 0 THEN RAISE EXCEPTION 'amount must be positive'; END IF;

  INSERT INTO public.credit_wallets (client_id, balance) VALUES (_client_id, 0)
  ON CONFLICT (client_id) DO NOTHING;

  UPDATE public.credit_wallets
    SET balance = balance - _amount,
        lifetime_spent = lifetime_spent + _amount
    WHERE client_id = _client_id AND balance >= _amount
    RETURNING balance INTO new_balance;

  IF new_balance IS NULL THEN RAISE EXCEPTION 'insufficient_credits'; END IF;

  INSERT INTO public.credit_ledger (client_id, delta, reason, description, generation_id)
  VALUES (_client_id, -_amount, _reason, _description, _generation_id);

  RETURN new_balance;
END;
$$;

CREATE OR REPLACE FUNCTION public.grant_credits(
  _client_id uuid, _amount integer, _reason ledger_reason,
  _description text, _purchase_id uuid
) RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE new_balance integer;
BEGIN
  IF _amount <= 0 THEN RAISE EXCEPTION 'amount must be positive'; END IF;
  INSERT INTO public.credit_wallets (client_id, balance, lifetime_purchased)
  VALUES (_client_id, _amount, CASE WHEN _reason='purchase' THEN _amount ELSE 0 END)
  ON CONFLICT (client_id) DO UPDATE
    SET balance = public.credit_wallets.balance + EXCLUDED.balance,
        lifetime_purchased = public.credit_wallets.lifetime_purchased +
          CASE WHEN _reason='purchase' THEN _amount ELSE 0 END
  RETURNING balance INTO new_balance;

  INSERT INTO public.credit_ledger (client_id, delta, reason, description, purchase_id)
  VALUES (_client_id, _amount, _reason, _description, _purchase_id);

  RETURN new_balance;
END;
$$;

GRANT EXECUTE ON FUNCTION public.spend_credits(uuid, integer, ledger_reason, text, uuid) TO anon, authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.grant_credits(uuid, integer, ledger_reason, text, uuid) TO anon, authenticated, service_role;

-- 8. Storage: permissive policies for the demo
DROP POLICY IF EXISTS "uploads owner read"  ON storage.objects;
DROP POLICY IF EXISTS "uploads owner write" ON storage.objects;
DROP POLICY IF EXISTS "renders owner read"  ON storage.objects;
DROP POLICY IF EXISTS "renders owner write" ON storage.objects;

CREATE POLICY "uploads anon all" ON storage.objects FOR ALL
  USING (bucket_id = 'uploads') WITH CHECK (bucket_id = 'uploads');
CREATE POLICY "renders anon all" ON storage.objects FOR ALL
  USING (bucket_id = 'renders') WITH CHECK (bucket_id = 'renders');
