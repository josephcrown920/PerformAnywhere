import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";

// Credits awarded per naira (tune freely). 1 NGN -> 1 credit means
// ₦1,000 -> 1,000 credits.
const CREDITS_PER_NAIRA = 1;

export const Route = createFileRoute("/api/public/paystack-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.PAYSTACK_SECRET_KEY;
        if (!secret) return new Response("not_configured", { status: 503 });

        const raw = await request.text();
        const sig = request.headers.get("x-paystack-signature") ?? "";
        const expected = createHmac("sha512", secret).update(raw).digest("hex");
        try {
          const a = Buffer.from(sig);
          const b = Buffer.from(expected);
          if (a.length !== b.length || !timingSafeEqual(a, b)) {
            return new Response("invalid_signature", { status: 401 });
          }
        } catch {
          return new Response("invalid_signature", { status: 401 });
        }

        let event: any;
        try { event = JSON.parse(raw); } catch { return new Response("bad_json", { status: 400 }); }
        if (event?.event !== "charge.success") return new Response("ignored", { status: 200 });

        const reference = event.data?.reference as string | undefined;
        const amountMinor = event.data?.amount as number | undefined; // kobo
        const clientId = event.data?.metadata?.client_id as string | undefined;
        if (!reference || !amountMinor || !clientId) {
          return new Response("missing_fields", { status: 400 });
        }
        if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(clientId)) {
          return new Response("invalid_client_id", { status: 400 });
        }

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const amountNaira = Math.floor(amountMinor / 100);
        const credits = amountNaira * CREDITS_PER_NAIRA;

        // Idempotent: unique on paystack_reference.
        const { data: existing } = await supabaseAdmin
          .from("purchases").select("id").eq("paystack_reference", reference).maybeSingle();
        if (existing) return new Response("duplicate", { status: 200 });

        const { data: purchase, error: pErr } = await supabaseAdmin.from("purchases").insert({
          client_id: clientId,
          paystack_reference: reference,
          amount_paid_minor: amountMinor,
          currency: event.data?.currency ?? "NGN",
          credits_allocated: credits,
          raw_event: event,
        }).select("id").single();
        if (pErr) return new Response(`insert_failed:${pErr.message}`, { status: 500 });

        const { error: gErr } = await supabaseAdmin.rpc("grant_credits", {
          _client_id: clientId,
          _amount: credits,
          _reason: "purchase",
          _description: `Paystack ${reference}`,
          _purchase_id: purchase.id,
        });
        if (gErr) return new Response(`grant_failed:${gErr.message}`, { status: 500 });

        return new Response("ok", { status: 200 });
      },
    },
  },
});
