import { createFileRoute, Outlet, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated")({
  component: AppLayout,
});

function AppLayout() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border/40 bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link to="/" className="flex items-center gap-2 font-display text-xl">
            <span className="inline-block h-2 w-2 rounded-full bg-primary" />
            Performance Studio
          </Link>
          <nav className="flex items-center gap-1 text-sm">
            <Link
              to="/projects"
              className="rounded px-3 py-1.5 text-muted-foreground hover:bg-accent hover:text-foreground"
              activeProps={{ className: "rounded px-3 py-1.5 text-foreground bg-accent" }}
            >
              Projects
            </Link>
            <Link
              to="/studio"
              className="rounded px-3 py-1.5 text-muted-foreground hover:bg-accent hover:text-foreground"
              activeProps={{ className: "rounded px-3 py-1.5 text-foreground bg-accent" }}
            >
              New
            </Link>
            <Link
              to="/orchestrate"
              className="rounded px-3 py-1.5 text-muted-foreground hover:bg-accent hover:text-foreground"
              activeProps={{ className: "rounded px-3 py-1.5 text-foreground bg-accent" }}
            >
              Orchestrate
            </Link>
            <Link
              to="/account"
              className="rounded px-3 py-1.5 text-muted-foreground hover:bg-accent hover:text-foreground"
              activeProps={{ className: "rounded px-3 py-1.5 text-foreground bg-accent" }}
            >
              Account
            </Link>
          </nav>
        </div>
      </header>
      <Outlet />
    </div>
  );
}
