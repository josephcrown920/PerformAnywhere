export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      credit_ledger: {
        Row: {
          client_id: string
          created_at: string
          delta: number
          description: string | null
          generation_id: string | null
          id: string
          purchase_id: string | null
          reason: Database["public"]["Enums"]["ledger_reason"]
        }
        Insert: {
          client_id: string
          created_at?: string
          delta: number
          description?: string | null
          generation_id?: string | null
          id?: string
          purchase_id?: string | null
          reason: Database["public"]["Enums"]["ledger_reason"]
        }
        Update: {
          client_id?: string
          created_at?: string
          delta?: number
          description?: string | null
          generation_id?: string | null
          id?: string
          purchase_id?: string | null
          reason?: Database["public"]["Enums"]["ledger_reason"]
        }
        Relationships: []
      }
      credit_wallets: {
        Row: {
          balance: number
          client_id: string
          created_at: string
          lifetime_purchased: number
          lifetime_spent: number
          updated_at: string
        }
        Insert: {
          balance?: number
          client_id: string
          created_at?: string
          lifetime_purchased?: number
          lifetime_spent?: number
          updated_at?: string
        }
        Update: {
          balance?: number
          client_id?: string
          created_at?: string
          lifetime_purchased?: number
          lifetime_spent?: number
          updated_at?: string
        }
        Relationships: []
      }
      generations: {
        Row: {
          client_id: string
          created_at: string
          credits_used: number
          duration_ms: number | null
          error_message: string | null
          id: string
          modality: Database["public"]["Enums"]["gen_modality"]
          model: string
          options: Json
          output: Json | null
          output_text: string | null
          output_url: string | null
          prompt: string | null
          provider: string
          status: Database["public"]["Enums"]["gen_status"]
          updated_at: string
        }
        Insert: {
          client_id: string
          created_at?: string
          credits_used?: number
          duration_ms?: number | null
          error_message?: string | null
          id?: string
          modality: Database["public"]["Enums"]["gen_modality"]
          model: string
          options?: Json
          output?: Json | null
          output_text?: string | null
          output_url?: string | null
          prompt?: string | null
          provider: string
          status?: Database["public"]["Enums"]["gen_status"]
          updated_at?: string
        }
        Update: {
          client_id?: string
          created_at?: string
          credits_used?: number
          duration_ms?: number | null
          error_message?: string | null
          id?: string
          modality?: Database["public"]["Enums"]["gen_modality"]
          model?: string
          options?: Json
          output?: Json | null
          output_text?: string | null
          output_url?: string | null
          prompt?: string | null
          provider?: string
          status?: Database["public"]["Enums"]["gen_status"]
          updated_at?: string
        }
        Relationships: []
      }
      project_assets: {
        Row: {
          client_id: string
          created_at: string
          id: string
          kind: Database["public"]["Enums"]["asset_kind"]
          mime_type: string | null
          project_id: string
          storage_path: string
        }
        Insert: {
          client_id: string
          created_at?: string
          id?: string
          kind: Database["public"]["Enums"]["asset_kind"]
          mime_type?: string | null
          project_id: string
          storage_path: string
        }
        Update: {
          client_id?: string
          created_at?: string
          id?: string
          kind?: Database["public"]["Enums"]["asset_kind"]
          mime_type?: string | null
          project_id?: string
          storage_path?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_assets_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      project_renders: {
        Row: {
          client_id: string
          created_at: string
          error_message: string | null
          id: string
          output_path: string | null
          project_id: string
          provider: Database["public"]["Enums"]["video_provider"]
          provider_job_id: string | null
          status: Database["public"]["Enums"]["project_status"]
          updated_at: string
        }
        Insert: {
          client_id: string
          created_at?: string
          error_message?: string | null
          id?: string
          output_path?: string | null
          project_id: string
          provider: Database["public"]["Enums"]["video_provider"]
          provider_job_id?: string | null
          status?: Database["public"]["Enums"]["project_status"]
          updated_at?: string
        }
        Update: {
          client_id?: string
          created_at?: string
          error_message?: string | null
          id?: string
          output_path?: string | null
          project_id?: string
          provider?: Database["public"]["Enums"]["video_provider"]
          provider_job_id?: string | null
          status?: Database["public"]["Enums"]["project_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "project_renders_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      projects: {
        Row: {
          client_id: string
          created_at: string
          enhanced_prompt: string | null
          error_message: string | null
          id: string
          provider: Database["public"]["Enums"]["video_provider"]
          scene_prompt: string | null
          status: Database["public"]["Enums"]["project_status"]
          style_prompt: string | null
          title: string
          updated_at: string
        }
        Insert: {
          client_id: string
          created_at?: string
          enhanced_prompt?: string | null
          error_message?: string | null
          id?: string
          provider?: Database["public"]["Enums"]["video_provider"]
          scene_prompt?: string | null
          status?: Database["public"]["Enums"]["project_status"]
          style_prompt?: string | null
          title?: string
          updated_at?: string
        }
        Update: {
          client_id?: string
          created_at?: string
          enhanced_prompt?: string | null
          error_message?: string | null
          id?: string
          provider?: Database["public"]["Enums"]["video_provider"]
          scene_prompt?: string | null
          status?: Database["public"]["Enums"]["project_status"]
          style_prompt?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      purchases: {
        Row: {
          amount_paid_minor: number
          client_id: string
          created_at: string
          credits_allocated: number
          currency: string
          id: string
          paystack_reference: string
          raw_event: Json | null
        }
        Insert: {
          amount_paid_minor: number
          client_id: string
          created_at?: string
          credits_allocated: number
          currency?: string
          id?: string
          paystack_reference: string
          raw_event?: Json | null
        }
        Update: {
          amount_paid_minor?: number
          client_id?: string
          created_at?: string
          credits_allocated?: number
          currency?: string
          id?: string
          paystack_reference?: string
          raw_event?: Json | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      grant_credits: {
        Args: {
          _amount: number
          _client_id: string
          _description: string
          _purchase_id: string
          _reason: Database["public"]["Enums"]["ledger_reason"]
        }
        Returns: number
      }
      spend_credits: {
        Args: {
          _amount: number
          _client_id: string
          _description: string
          _generation_id: string
          _reason: Database["public"]["Enums"]["ledger_reason"]
        }
        Returns: number
      }
    }
    Enums: {
      asset_kind: "performance" | "identity" | "outfit" | "scene"
      gen_modality: "text" | "image" | "video" | "audio" | "inference" | "sync"
      gen_status: "queued" | "running" | "succeeded" | "failed"
      ledger_reason:
        | "purchase"
        | "generation"
        | "refund"
        | "grant"
        | "adjustment"
      project_status: "draft" | "queued" | "running" | "succeeded" | "failed"
      video_provider: "runway" | "kling" | "hailuo"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      asset_kind: ["performance", "identity", "outfit", "scene"],
      gen_modality: ["text", "image", "video", "audio", "inference", "sync"],
      gen_status: ["queued", "running", "succeeded", "failed"],
      ledger_reason: [
        "purchase",
        "generation",
        "refund",
        "grant",
        "adjustment",
      ],
      project_status: ["draft", "queued", "running", "succeeded", "failed"],
      video_provider: ["runway", "kling", "hailuo"],
    },
  },
} as const
