// Per-browser anonymous identity. Replaces auth.uid() now that the app has no accounts.
// Stored in localStorage as a v4 UUID; survives reloads, cleared by "Reset session".

const KEY = "ps_client_id";

export function getClientId(): string {
  if (typeof window === "undefined") {
    throw new Error("getClientId() is browser-only");
  }
  let id = window.localStorage.getItem(KEY);
  if (!id || !isUuid(id)) {
    id = crypto.randomUUID();
    window.localStorage.setItem(KEY, id);
  }
  return id;
}

export function resetClientId(): string {
  if (typeof window === "undefined") {
    throw new Error("resetClientId() is browser-only");
  }
  const id = crypto.randomUUID();
  window.localStorage.setItem(KEY, id);
  return id;
}

function isUuid(s: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
}
