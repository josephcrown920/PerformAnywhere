import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createAnonClient, assertClientId } from "@/lib/supabase-anon.server";

// Orchestrates a video render: build provider input from signed URLs,
// try the user's preferred provider, fall back on failure.

const StartInput = z.object({ clientId: z.string().uuid(), projectId: z.string().uuid() });
const PollInput = z.object({ clientId: z.string().uuid(), projectId: z.string().uuid() });
const RetryInput = z.object({
  clientId: z.string().uuid(),
  projectId: z.string().uuid(),
  provider: z.enum(["runway", "kling", "hailuo"]),
});

async function signedUrl(supabase: any, path: string, bucket = "uploads") {
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, 60 * 60);
  if (error || !data) throw new Error(`Could not sign ${bucket}/${path}: ${error?.message}`);
  return data.signedUrl as string;
}

export const startRender = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => StartInput.parse(d))
  .handler(async ({ data }) => {
    const supabase = createAnonClient();
    const clientId = assertClientId(data.clientId);

    const { data: project, error: pErr } = await supabase
      .from("projects")
      .select("*")
      .eq("id", data.projectId)
      .eq("client_id", clientId)
      .single();
    if (pErr || !project) throw new Error("Project not found");

    const { data: assets, error: aErr } = await supabase
      .from("project_assets")
      .select("kind,storage_path")
      .eq("project_id", project.id);
    if (aErr) throw new Error(aErr.message);

    const byKind = Object.fromEntries(assets.map((a: any) => [a.kind, a.storage_path]));
    if (!byKind.performance || !byKind.identity) {
      throw new Error("Performance video and identity photo are required");
    }

    const performanceUrl = await signedUrl(supabase, byKind.performance);
    const identityUrl = await signedUrl(supabase, byKind.identity);
    const outfitUrl = byKind.outfit ? await signedUrl(supabase, byKind.outfit) : undefined;
    const sceneUrl = byKind.scene ? await signedUrl(supabase, byKind.scene) : undefined;
    const prompt = project.enhanced_prompt || project.style_prompt || project.scene_prompt || "Cinematic restage.";

    const { pickProviderChain, PROVIDERS } = await import("@/lib/providers/registry.server");
    const chain = pickProviderChain(project.provider);

    let lastError = "";
    for (const id of chain) {
      const provider = PROVIDERS[id];
      if (!provider.isConfigured()) {
        lastError = `${provider.label} not configured`;
        continue;
      }
      try {
        const { jobId } = await provider.submit({
          performanceUrl,
          identityUrl,
          outfitUrl,
          sceneUrl,
          prompt,
        });
        await supabase
          .from("projects")
          .update({ status: "queued", provider: id, error_message: null })
          .eq("id", project.id);
        await supabase.from("project_renders").insert({
          project_id: project.id,
          client_id: clientId,
          provider: id,
          provider_job_id: jobId,
          status: "queued",
        });
        return { ok: true, provider: id, jobId };
      } catch (err) {
        lastError = err instanceof Error ? err.message : String(err);
        continue;
      }
    }

    await supabase
      .from("projects")
      .update({ status: "failed", error_message: lastError || "No provider available" })
      .eq("id", project.id);
    throw new Error(lastError || "No provider could accept this job");
  });

export const pollRender = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => PollInput.parse(d))
  .handler(async ({ data }) => {
    const supabase = createAnonClient();
    const clientId = assertClientId(data.clientId);

    const { data: render, error } = await supabase
      .from("project_renders")
      .select("*")
      .eq("project_id", data.projectId)
      .eq("client_id", clientId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!render) return { status: "queued" as const };

    if (render.status === "succeeded" || render.status === "failed") {
      return {
        status: render.status as "succeeded" | "failed",
        outputPath: render.output_path,
        error: render.error_message,
        provider: render.provider,
      };
    }

    const { PROVIDERS } = await import("@/lib/providers/registry.server");
    const provider = PROVIDERS[render.provider as keyof typeof PROVIDERS];
    if (!provider.isConfigured() || !render.provider_job_id) {
      return { status: render.status as "queued" | "running", provider: render.provider };
    }

    let result;
    try {
      result = await provider.poll(render.provider_job_id);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      await supabase.from("project_renders").update({ status: "failed", error_message: msg }).eq("id", render.id);
      await supabase.from("projects").update({ status: "failed", error_message: msg }).eq("id", data.projectId);
      return { status: "failed" as const, error: msg, provider: render.provider };
    }

    if (result.status === "succeeded" && result.url) {
      const fileRes = await fetch(result.url);
      if (!fileRes.ok) {
        return { status: "running" as const, provider: render.provider };
      }
      const bytes = new Uint8Array(await fileRes.arrayBuffer());
      const path = `${clientId}/${data.projectId}/${render.id}.mp4`;
      const { error: upErr } = await supabase.storage.from("renders").upload(path, bytes, {
        contentType: "video/mp4",
        upsert: true,
      });
      if (upErr) {
        await supabase.from("project_renders").update({ status: "failed", error_message: upErr.message }).eq("id", render.id);
        return { status: "failed" as const, error: upErr.message, provider: render.provider };
      }
      await supabase.from("project_renders").update({ status: "succeeded", output_path: path }).eq("id", render.id);
      await supabase.from("projects").update({ status: "succeeded", error_message: null }).eq("id", data.projectId);
      return { status: "succeeded" as const, outputPath: path, provider: render.provider };
    }

    if (result.status === "failed") {
      await supabase.from("project_renders").update({ status: "failed", error_message: result.error }).eq("id", render.id);
      await supabase.from("projects").update({ status: "failed", error_message: result.error }).eq("id", data.projectId);
      return { status: "failed" as const, error: result.error, provider: render.provider };
    }

    if (result.status !== render.status) {
      await supabase.from("project_renders").update({ status: result.status }).eq("id", render.id);
      await supabase.from("projects").update({ status: result.status }).eq("id", data.projectId);
    }
    return { status: result.status, provider: render.provider };
  });

export const retryRender = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => RetryInput.parse(d))
  .handler(async ({ data }) => {
    const supabase = createAnonClient();
    assertClientId(data.clientId);
    await supabase
      .from("projects")
      .update({ provider: data.provider, status: "draft", error_message: null })
      .eq("id", data.projectId)
      .eq("client_id", data.clientId);
    return { ok: true };
  });

export const getRenderSignedUrl = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ path: z.string() }).parse(d))
  .handler(async ({ data }) => {
    const supabase = createAnonClient();
    const { data: signed, error } = await supabase.storage.from("renders").createSignedUrl(data.path, 3600);
    if (error || !signed) throw new Error(error?.message ?? "Could not sign URL");
    return { url: signed.signedUrl };
  });

export const getAssetSignedUrl = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => z.object({ path: z.string() }).parse(d))
  .handler(async ({ data }) => {
    const supabase = createAnonClient();
    const { data: signed, error } = await supabase.storage.from("uploads").createSignedUrl(data.path, 3600);
    if (error || !signed) throw new Error(error?.message ?? "Could not sign URL");
    return { url: signed.signedUrl };
  });

export const getProviderStatus = createServerFn({ method: "GET" })
  .handler(async () => {
    const { PROVIDERS } = await import("@/lib/providers/registry.server");
    return Object.values(PROVIDERS).map((p) => ({
      id: p.id,
      label: p.label,
      configured: p.isConfigured(),
    }));
  });
