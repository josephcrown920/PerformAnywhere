# Orchestrate Module — Integration Guide

A self-contained AI generation layer (text / image / video / audio) with
provider fallback, credit-gating, and Paystack billing. Designed to drop into
any TanStack Start / Node / Worker app with minimal coupling.

---

## Architecture

```
src/lib/orchestrate/
├── catalog.ts            # model registry + credit pricing  (zero deps)
├── providers.server.ts   # raw provider adapters             (env vars only)
└── run.server.ts         # portable runner + fallback chain  (no DB, no auth)

src/lib/orchestrate.functions.ts   # TanStack server fns: credits + DB + Paystack
src/routes/_authenticated/orchestrate.tsx  # reference UI
src/routes/api/public/paystack-webhook.ts  # credit top-up webhook
```

Three layers, each usable independently:

| Layer | File | Depends on | Use when |
|---|---|---|---|
| Adapters | `providers.server.ts` | `process.env.*` only | You want to call one provider directly. |
| Runner | `run.server.ts` | adapters + catalog | You want fallback chain but **no credits/DB**. Drop into any app. |
| Server fns | `orchestrate.functions.ts` | runner + Supabase | Full credit ledger, history, Paystack. |

---

## Drop into a bigger app (no credits, no DB)

Copy three files: `catalog.ts`, `providers.server.ts`, `run.server.ts`.
No Supabase, no auth — works in any server runtime with `fetch` + `crypto.subtle`.

```ts
import { runOrchestrated } from "@/lib/orchestrate/run.server";

const r = await runOrchestrated({
  modality: "text",
  modelId: "lovable/google/gemini-2.5-flash",
  prompt: "summarize quantum entanglement in 2 lines",
});
console.log(r.output_text, r.attempts);
```

Returns:
```ts
{
  provider: "lovable",
  model: "google/gemini-2.5-flash",
  output_text: "...",
  duration_ms: 812,
  attempts: [],          // failed providers tried before success
}
```

If the requested provider is unconfigured or errors, the runner automatically
tries the next provider in the fallback chain. Override the chain per call:

```ts
runOrchestrated({
  modality: "image",
  modelId: "lovable/google/gemini-2.5-flash-image",
  prompt: "neon city",
  fallback: ["pollinations", "fal"],  // only these on failure
});
```

---

## Required env vars

| Var | Required for | Notes |
|---|---|---|
| `LOVABLE_API_KEY` | text/image via Lovable gateway | Provisioned automatically on Lovable Cloud. |
| `GEMINI_API_KEY` | direct Gemini text | optional fallback |
| `HUGGINGFACE_API_KEY` | HF inference | text + image; uses `router.huggingface.co` |
| `REPLICATE_API_TOKEN` | replicate text/image/video/audio | |
| `KLING_ACCESS_KEY` + `KLING_SECRET_KEY` | Kling video | JWT signed in-handler |
| `FAL_KEY` | Fal image/video | optional |
| `GROQ_API_KEY`, `MISTRAL_API_KEY`, `OPENAI_API_KEY`, `COHERE_API_KEY` | extra text fallbacks | optional |
| `ELEVENLABS_API_KEY` | TTS | optional |
| `RUNWARE_API_KEY` | Runware images | optional |
| `PAYSTACK_SECRET_KEY` | credit top-ups | only if billing layer is used |

Missing keys are not errors — adapters throw `ProviderUnconfigured` and the
runner moves on.

---

## Smoke test results (last run)

| Provider | Status | Note |
|---|---|---|
| text/lovable | ✅ | working |
| text/pollinations | ✅ | working, no key needed |
| text/gemini (direct) | ⚠️ 429 | API key valid, free quota exhausted — fallback handles it |
| text/huggingface | ✅ | endpoint patched to `router.huggingface.co` |
| image/pollinations | ✅ | working, no key needed |
| replicate (auth) | ✅ | token valid (no credits per user) |
| video/kling (auth) | ✅ | JWT + endpoint OK |
| db/has_role RPC | ✅ | working |

---

## Integration checklist for a bigger app

1. **Copy** `src/lib/orchestrate/` (3 files).
2. **Set** the env vars you want active. None are required — the runner degrades gracefully.
3. **Call** `runOrchestrated(...)` from any server fn / route handler / cron.
4. **(Optional) credit layer**: copy the migrations in `supabase/migrations/` and `orchestrate.functions.ts`.
5. **(Optional) billing**: copy `src/routes/api/public/paystack-webhook.ts` + add `PAYSTACK_SECRET_KEY`.

The adapters use only `fetch` + Web Crypto + Node `Buffer` — they run on
Cloudflare Workers, Bun, Node 18+, and Deno without changes.

---

## Stability notes

- Every adapter wraps non-2xx in a tagged error → runner treats as recoverable.
- `ProviderUnconfigured` is distinguished from real errors in `attempts`.
- Kling/Fal video adapters poll up to ~10 min; wrap calls in your queue if you need shorter SLAs.
- Credits are **pre-spent then refunded** on total failure (atomic via RPC).
- The runner never throws on a single provider failure — only when the entire chain is exhausted.
