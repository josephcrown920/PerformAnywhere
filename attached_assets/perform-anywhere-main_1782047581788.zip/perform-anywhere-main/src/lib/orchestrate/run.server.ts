// Portable, dependency-free orchestration core.
// No Supabase, no credits, no auth — just providers + fallback chain.
// Suitable for dropping into any TanStack Start / Node / Bun / Worker app.
//
// Usage:
//   import { runOrchestrated } from "@/lib/orchestrate/run.server";
//   const r = await runOrchestrated({
//     modality: "text", modelId: "lovable/google/gemini-2.5-flash", prompt: "hi",
//   });

import { ADAPTERS, ProviderUnconfigured, type AdapterResult } from "./providers.server";
import { CATALOG, type Modality } from "./catalog";

export type RunOrchestratedInput = {
  modality: Modality;
  /** "provider/model", e.g. "lovable/google/gemini-2.5-flash" or "kling/kling-v1-6". */
  modelId: string;
  prompt: string;
  options?: Record<string, any>;
  /** Override fallback order. Defaults to sensible per-modality chain. */
  fallback?: string[];
};

export type RunOrchestratedResult = AdapterResult & {
  duration_ms: number;
  attempts: { provider: string; error: string }[];
};

const DEFAULT_FALLBACKS: Record<Modality, string[]> = {
  text:  ["lovable", "gemini", "groq", "mistral", "pollinations", "huggingface", "openai", "cohere"],
  image: ["lovable", "pollinations", "huggingface", "fal", "replicate", "runware"],
  video: ["kling", "fal", "replicate"],
  audio: ["elevenlabs", "replicate"],
};

function pickDefaultModel(modality: Modality, provider: string): string {
  return CATALOG[modality].find((m) => m.provider === provider)?.model ?? "";
}

export async function runOrchestrated(input: RunOrchestratedInput): Promise<RunOrchestratedResult> {
  if (!input?.modality || !input?.modelId || !input?.prompt) {
    throw new Error("missing_fields");
  }
  const [requested, ...rest] = input.modelId.split("/");
  const requestedModel = rest.join("/");
  const adapters = ADAPTERS[input.modality];
  const chain = [requested, ...((input.fallback ?? DEFAULT_FALLBACKS[input.modality]).filter((p) => p !== requested))];
  const attempts: { provider: string; error: string }[] = [];
  const started = Date.now();

  for (const provider of chain) {
    const adapter = adapters[provider as keyof typeof adapters];
    if (!adapter) { attempts.push({ provider, error: "no_adapter" }); continue; }
    try {
      const result = await adapter({
        model: provider === requested ? requestedModel : pickDefaultModel(input.modality, provider),
        prompt: input.prompt,
        options: input.options,
      });
      return { ...result, duration_ms: Date.now() - started, attempts };
    } catch (e: any) {
      attempts.push({ provider, error: e instanceof ProviderUnconfigured ? "unconfigured" : (e?.message ?? String(e)) });
    }
  }
  throw new Error(`all_providers_failed: ${attempts.map((a) => `${a.provider}:${a.error}`).join(" | ")}`);
}

export { ADAPTERS, ProviderUnconfigured, CATALOG };
export type { Modality, AdapterResult };
