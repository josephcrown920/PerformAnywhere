import { createServerFn } from "@tanstack/react-start";
import { estimateCredits, type Modality } from "@/lib/orchestrate/catalog";
import { createAnonClient, assertClientId } from "@/lib/supabase-anon.server";

type RunInput = {
  clientId: string;
  modality: Modality;
  modelId: string;     // "provider/model"
  prompt: string;
  options?: Record<string, any>;
};

export const runGeneration = createServerFn({ method: "POST" })
  .inputValidator((d: RunInput) => {
    assertClientId(d?.clientId);
    if (!d?.modality || !d?.modelId || !d?.prompt) throw new Error("missing_fields");
    if (d.prompt.length > 8000) throw new Error("prompt_too_long");
    return d;
  })
  .handler(async ({ data }) => {
    const { runOrchestrated } = await import("@/lib/orchestrate/run.server");
    const supabase = createAnonClient();
    const clientId = data.clientId;

    const [requestedProvider, ...modelParts] = data.modelId.split("/");
    const modelName = modelParts.join("/");
    const cost = estimateCredits(data.modality, data.options ?? {});

    // 1. Ensure wallet exists and has balance.
    await supabase.from("credit_wallets").upsert(
      { client_id: clientId, balance: 50 },
      { onConflict: "client_id", ignoreDuplicates: true },
    );
    const { data: wallet } = await supabase
      .from("credit_wallets").select("balance").eq("client_id", clientId).maybeSingle();
    if (!wallet || wallet.balance < cost) {
      throw new Error(`insufficient_credits:need=${cost}:have=${wallet?.balance ?? 0}`);
    }

    // 2. Insert generation row.
    const { data: gen, error: genErr } = await supabase.from("generations").insert({
      client_id: clientId,
      modality: data.modality,
      provider: requestedProvider,
      model: modelName,
      prompt: data.prompt,
      options: data.options ?? {},
      status: "running",
    }).select("id").single();
    if (genErr || !gen) throw new Error(`generation_insert_failed:${genErr?.message}`);

    // 3. Pre-spend credits atomically.
    const { error: spendErr } = await supabase.rpc("spend_credits", {
      _client_id: clientId, _amount: cost, _reason: "generation",
      _description: `${data.modality}/${data.modelId}`, _generation_id: gen.id,
    });
    if (spendErr) {
      await supabase.from("generations").update({
        status: "failed", error_message: spendErr.message,
      }).eq("id", gen.id);
      throw new Error(`spend_failed:${spendErr.message}`);
    }

    // 4. Run via portable orchestrator (handles fallback chain).
    try {
      const result = await runOrchestrated({
        modality: data.modality, modelId: data.modelId,
        prompt: data.prompt, options: data.options,
      });
      await supabase.from("generations").update({
        status: "succeeded",
        provider: result.provider,
        model: result.model,
        output_url: result.output_url ?? null,
        output_text: result.output_text ?? null,
        credits_used: cost,
        duration_ms: result.duration_ms,
      }).eq("id", gen.id);
      return {
        id: gen.id,
        provider: result.provider,
        model: result.model,
        output_url: result.output_url,
        output_text: result.output_text,
        credits_used: cost,
        duration_ms: result.duration_ms,
        fallbacks_attempted: result.attempts.map((a) => `${a.provider}:${a.error}`),
      };
    } catch (e: any) {
      // Refund on total failure.
      await supabase.rpc("grant_credits", {
        _client_id: clientId, _amount: cost, _reason: "refund",
        _description: `refund:${gen.id}`, _purchase_id: undefined as unknown as string,
      });
      await supabase.from("generations").update({
        status: "failed", error_message: e?.message ?? String(e), credits_used: 0,
      }).eq("id", gen.id);
      throw e;
    }
  });

export const getWallet = createServerFn({ method: "POST" })
  .inputValidator((d: { clientId: string }) => ({ clientId: assertClientId(d?.clientId) }))
  .handler(async ({ data }) => {
    const supabase = createAnonClient();
    // Seed a wallet with 50 starter credits on first call.
    await supabase.from("credit_wallets").upsert(
      { client_id: data.clientId, balance: 50 },
      { onConflict: "client_id", ignoreDuplicates: true },
    );
    const { data: wallet } = await supabase
      .from("credit_wallets")
      .select("balance, lifetime_purchased, lifetime_spent")
      .eq("client_id", data.clientId).maybeSingle();
    return wallet ?? { balance: 0, lifetime_purchased: 0, lifetime_spent: 0 };
  });

export const listGenerations = createServerFn({ method: "POST" })
  .inputValidator((d: { clientId: string }) => ({ clientId: assertClientId(d?.clientId) }))
  .handler(async ({ data }) => {
    const supabase = createAnonClient();
    const { data: rows } = await supabase
      .from("generations")
      .select("id, modality, provider, model, prompt, status, output_url, output_text, credits_used, created_at")
      .eq("client_id", data.clientId)
      .order("created_at", { ascending: false })
      .limit(30);
    return rows ?? [];
  });

export const initPaystackPurchase = createServerFn({ method: "POST" })
  .inputValidator((d: { clientId: string; amountNaira: number; email: string }) => {
    assertClientId(d?.clientId);
    const n = Number(d?.amountNaira);
    if (!Number.isFinite(n) || n < 500 || n > 5_000_000) throw new Error("invalid_amount");
    if (!d?.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(d.email)) throw new Error("invalid_email");
    return { clientId: d.clientId, amountNaira: Math.floor(n), email: d.email };
  })
  .handler(async ({ data }) => {
    const key = process.env.PAYSTACK_SECRET_KEY;
    if (!key) throw new Error("paystack_not_configured");

    const res = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        email: data.email,
        amount: data.amountNaira * 100, // kobo
        metadata: { client_id: data.clientId },
      }),
    });
    if (!res.ok) throw new Error(`paystack_init_failed:${res.status}`);
    const j = await res.json();
    return { authorization_url: j.data?.authorization_url, reference: j.data?.reference };
  });
