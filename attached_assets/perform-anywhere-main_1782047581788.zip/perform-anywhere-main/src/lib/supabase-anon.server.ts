// Server-side publishable-key Supabase client. Used by server functions now that
// the app is fully anonymous — RLS policies are permissive, scoping is done by
// `client_id` inside each handler.

import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

export function createAnonClient() {
  return createClient<Database>(
    process.env.SUPABASE_URL!,
    process.env.SUPABASE_PUBLISHABLE_KEY!,
    {
      auth: {
        storage: undefined,
        persistSession: false,
        autoRefreshToken: false,
      },
    },
  );
}

export function assertClientId(clientId: unknown): string {
  if (
    typeof clientId !== "string" ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(clientId)
  ) {
    throw new Error("invalid_client_id");
  }
  return clientId;
}
