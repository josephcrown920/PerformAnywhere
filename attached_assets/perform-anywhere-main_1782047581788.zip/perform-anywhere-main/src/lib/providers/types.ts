// Shared provider types + adapter registry.
// Each adapter is responsible for submitting jobs and polling status against
// its external API. Stubs throw `not_configured` until an API key is added.

export type ProviderId = "runway" | "kling" | "hailuo";

export type ProviderInput = {
  performanceUrl: string; // signed URL to the driving video
  identityUrl: string;
  outfitUrl?: string;
  sceneUrl?: string;
  prompt: string;
};

export type ProviderJobStatus = {
  status: "queued" | "running" | "succeeded" | "failed";
  url?: string;
  error?: string;
};

export interface VideoProvider {
  id: ProviderId;
  label: string;
  isConfigured(): boolean;
  submit(input: ProviderInput): Promise<{ jobId: string }>;
  poll(jobId: string): Promise<ProviderJobStatus>;
}

export class NotConfiguredError extends Error {
  code = "not_configured" as const;
  constructor(provider: ProviderId) {
    super(`${provider} API key is not configured`);
  }
}
