// Runway adapter. Uses Runway's character-performance / image-to-video API.
// Real API endpoints and request shapes are kept minimal — we treat the
// Runway response as opaque and just persist the job id.
//
// Docs: https://docs.dev.runwayml.com (Act-Two / Gen-4 References)

import { NotConfiguredError, type ProviderInput, type ProviderJobStatus, type VideoProvider } from "./types";

const BASE = "https://api.dev.runwayml.com/v1";

function key() {
  const k = process.env.RUNWAY_API_KEY;
  if (!k) throw new NotConfiguredError("runway");
  return k;
}

export const runwayProvider: VideoProvider = {
  id: "runway",
  label: "Runway (Act-Two)",
  isConfigured: () => Boolean(process.env.RUNWAY_API_KEY),

  async submit(input: ProviderInput) {
    const apiKey = key();
    const res = await fetch(`${BASE}/character_performance`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
        "X-Runway-Version": "2024-11-06",
      },
      body: JSON.stringify({
        character: { type: "image", uri: input.identityUrl },
        reference: { type: "video", uri: input.performanceUrl },
        promptText: input.prompt,
        ratio: "1280:720",
        bodyControl: true,
        expressionIntensity: 3,
      }),
    });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Runway submit failed (${res.status}): ${text}`);
    }
    const json = (await res.json()) as { id: string };
    return { jobId: json.id };
  },

  async poll(jobId: string): Promise<ProviderJobStatus> {
    const apiKey = key();
    const res = await fetch(`${BASE}/tasks/${jobId}`, {
      headers: { Authorization: `Bearer ${apiKey}`, "X-Runway-Version": "2024-11-06" },
    });
    if (!res.ok) {
      const text = await res.text();
      return { status: "failed", error: `Runway poll ${res.status}: ${text}` };
    }
    const json = (await res.json()) as {
      status: string;
      output?: string[];
      failure?: string;
    };
    switch (json.status) {
      case "SUCCEEDED":
        return { status: "succeeded", url: json.output?.[0] };
      case "FAILED":
      case "CANCELLED":
        return { status: "failed", error: json.failure ?? json.status };
      case "RUNNING":
      case "THROTTLED":
        return { status: "running" };
      default:
        return { status: "queued" };
    }
  },
};
