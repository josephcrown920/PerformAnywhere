import { NotConfiguredError, type VideoProvider } from "./types";

export const hailuoProvider: VideoProvider = {
  id: "hailuo",
  label: "Hailuo / MiniMax",
  isConfigured: () => Boolean(process.env.MINIMAX_API_KEY),
  async submit() {
    if (!process.env.MINIMAX_API_KEY) throw new NotConfiguredError("hailuo");
    throw new Error("Hailuo adapter not implemented yet — add MINIMAX_API_KEY and wire endpoints.");
  },
  async poll() {
    throw new Error("Hailuo adapter not implemented");
  },
};
