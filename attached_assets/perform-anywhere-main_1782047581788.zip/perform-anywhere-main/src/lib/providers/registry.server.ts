import type { ProviderId, VideoProvider } from "./types";
import { runwayProvider } from "./runway.server";
import { klingProvider } from "./kling.server";
import { hailuoProvider } from "./stubs.server";

export const PROVIDERS: Record<ProviderId, VideoProvider> = {
  runway: runwayProvider,
  kling: klingProvider,
  hailuo: hailuoProvider,
};

// Default to Kling first since the user has Kling credentials.
export const PROVIDER_FALLBACK: ProviderId[] = ["kling", "runway", "hailuo"];

export function pickProviderChain(preferred: ProviderId): ProviderId[] {
  return [preferred, ...PROVIDER_FALLBACK.filter((p) => p !== preferred)];
}
