// Kling AI provider — image-to-video via official JWT-signed API.
// Docs: https://docs.qingque.cn/d/home/eZQDqMcCXfL4kbCUYWG7-uBb_
//
// Uses identity image as the source frame; the user's performance video is
// described via the prompt (true motion transfer needs Runway Act-Two).
// Requires KLING_ACCESS_KEY + KLING_SECRET_KEY.

import { NotConfiguredError, type ProviderInput, type ProviderJobStatus, type VideoProvider } from "./types";

const BASE = "https://api-singapore.klingai.com";

function b64url(input: Uint8Array | string): string {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function signJwt(): Promise<string> {
  const ak = process.env.KLING_ACCESS_KEY;
  const sk = process.env.KLING_SECRET_KEY;
  if (!ak || !sk) throw new NotConfiguredError("kling");
  const header = b64url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const now = Math.floor(Date.now() / 1000);
  const payload = b64url(JSON.stringify({ iss: ak, exp: now + 1800, nbf: now - 5 }));
  const data = `${header}.${payload}`;
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(sk),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", cryptoKey, new TextEncoder().encode(data));
  return `${data}.${b64url(new Uint8Array(sig))}`;
}

export const klingProvider: VideoProvider = {
  id: "kling",
  label: "Kling 1.6 (image-to-video)",
  isConfigured: () => Boolean(process.env.KLING_ACCESS_KEY && process.env.KLING_SECRET_KEY),

  async submit(input: ProviderInput) {
    const token = await signJwt();
    const res = await fetch(`${BASE}/v1/videos/image2video`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        model_name: "kling-v1-6",
        mode: "std",
        duration: "5",
        image: input.identityUrl,
        prompt: input.prompt.slice(0, 2500),
        cfg_scale: 0.5,
      }),
    });
    const text = await res.text();
    if (!res.ok) throw new Error(`Kling submit ${res.status}: ${text}`);
    const json = JSON.parse(text) as { code: number; message: string; data: { task_id: string } };
    if (json.code !== 0) throw new Error(`Kling submit error ${json.code}: ${json.message}`);
    return { jobId: json.data.task_id };
  },

  async poll(jobId: string): Promise<ProviderJobStatus> {
    const token = await signJwt();
    const res = await fetch(`${BASE}/v1/videos/image2video/${jobId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    const text = await res.text();
    if (!res.ok) return { status: "failed", error: `Kling poll ${res.status}: ${text}` };
    const json = JSON.parse(text) as {
      code: number;
      message: string;
      data: { task_status: string; task_status_msg?: string; task_result?: { videos?: Array<{ url: string }> } };
    };
    if (json.code !== 0) return { status: "failed", error: json.message };
    switch (json.data.task_status) {
      case "succeed":
        return { status: "succeeded", url: json.data.task_result?.videos?.[0]?.url };
      case "failed":
        return { status: "failed", error: json.data.task_status_msg ?? "kling failed" };
      case "processing":
        return { status: "running" };
      default:
        return { status: "queued" };
    }
  },
};
