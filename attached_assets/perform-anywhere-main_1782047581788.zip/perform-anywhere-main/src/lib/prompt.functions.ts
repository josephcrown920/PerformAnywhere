import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

// Build an enhanced video prompt from the user's references and style notes
// via Lovable AI Gateway (Gemini). Server-only — uses LOVABLE_API_KEY.

const Input = z.object({
  scenePrompt: z.string().max(2000).optional().default(""),
  stylePrompt: z.string().max(2000).optional().default(""),
  hasOutfit: z.boolean(),
  hasScene: z.boolean(),
  hasIdentity: z.boolean(),
});

export const enhancePrompt = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => Input.parse(data))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("AI Gateway not configured");

    const system = `You are a cinematic prompt engineer for AI video-to-video models.
Given the user's scene and style notes, write ONE rich prompt (max 90 words)
describing the new performance video. Preserve the subject's identity from the
identity photo, restage the same body movement and timing from the driving
clip, place them in the requested scene, apply the outfit, and apply the
cinematic style. Be vivid but concrete. No camera-direction headers, no lists —
prose only.`;

    const user = [
      data.hasIdentity ? "Identity: keep the face from the reference photo." : null,
      data.hasOutfit ? "Outfit: as shown in the outfit reference image." : null,
      data.hasScene ? `Scene reference provided.` : null,
      data.scenePrompt ? `Scene notes: ${data.scenePrompt}` : null,
      data.stylePrompt ? `Style notes: ${data.stylePrompt}` : null,
    ]
      .filter(Boolean)
      .join("\n");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Lovable-API-Key": key,
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: system },
          { role: "user", content: user || "Generic cinematic restage." },
        ],
      }),
    });
    if (res.status === 429) throw new Error("AI rate limit — try again shortly.");
    if (res.status === 402) throw new Error("AI credits exhausted — add credits in workspace billing.");
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`AI Gateway error: ${text.slice(0, 300)}`);
    }
    const json = (await res.json()) as { choices: { message: { content: string } }[] };
    const text = json.choices?.[0]?.message?.content?.trim() ?? "";
    return { prompt: text };
  });
