/**
 * Minimal end-to-end example of the portable orchestration runner.
 *
 * Run with:
 *   bun run examples/minimal-runOrchestrated.ts "summarize quantum entanglement in 2 lines"
 *
 * Required env: at least ONE of
 *   LOVABLE_API_KEY, GEMINI_API_KEY, HUGGINGFACE_API_KEY, OPENAI_API_KEY,
 *   GROQ_API_KEY, MISTRAL_API_KEY, COHERE_API_KEY
 * (Pollinations works with no key as a free fallback.)
 *
 * This file imports ONLY the portable runner — no Supabase, no auth, no DB.
 * Copy `src/lib/orchestrate/{catalog,providers.server,run.server}.ts` into any
 * Node/Bun/Worker project and you can use it the same way.
 */
import { runOrchestrated } from "../src/lib/orchestrate/run.server";

async function main() {
  const prompt = process.argv.slice(2).join(" ") || "Say hello in one short sentence.";

  console.log(`\n▶  prompt: ${prompt}\n`);

  const result = await runOrchestrated({
    modality: "text",
    modelId: "lovable/google/gemini-2.5-flash",
    prompt,
    // Override fallback to demonstrate: try lovable, then free pollinations.
    fallback: ["lovable", "gemini", "pollinations", "huggingface"],
  });

  console.log("✅ provider :", result.provider);
  console.log("✅ model    :", result.model);
  console.log("⏱  duration :", result.duration_ms, "ms");
  if (result.attempts.length) {
    console.log("↩  fallback :");
    for (const a of result.attempts) console.log(`   - ${a.provider}: ${a.error}`);
  }
  console.log("\n--- output ---\n" + (result.output_text ?? JSON.stringify(result, null, 2)));
}

main().catch((e) => {
  console.error("❌ all providers failed:", e?.message ?? e);
  process.exit(1);
});
